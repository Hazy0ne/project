----------------------------------
Window Ruler for Windows Platforms
----------------------------------

Window Ruler is a program that permits you to:
- Test if your application windows fit in a certain screen resolution (very useful for developers!);
- Measure any window by dragging the red ball (left-upper corner).

How to use this program:
- Move the ruler by dragging it
- Measure a certain window by dragging the red ball over it
- Show/Hide the ruler by left-clicking over the notify icon
- Show the options by right-clicking over the notify icon or the ruler window
- The ruler can be resized using the mouse

This Program is freeware. See the file 'license.txt'.

Please send bugs or suggestion at http://www.hexagora.com

--===========================================--
--    Copyright by Lorenzi Davide 2006-10    --
--===========================================--
---    Download the latest version and      ---
--          additional designs from          --
=           http://www.hexagora.com           =
--===========================================--

This product includes software developed by vbAccelerator (http://vbaccelerator.com/).